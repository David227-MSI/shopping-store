<template>
  <main>
    <h2>這是首頁</h2>
  </main>
</template>

<script setup>
</script>
