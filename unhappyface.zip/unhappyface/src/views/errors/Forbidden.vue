<template>
    <h3>403 Forbidden 權限不足</h3>

</template>
    
<script setup>
    
</script>
    
<style>
    
</style>