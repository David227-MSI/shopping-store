<template>
  <Main />
</template>

<script setup>
import Main from '@/components/Main.vue'
</script>

<style scoped>
/* 可加全局樣式調整 */
</style>
